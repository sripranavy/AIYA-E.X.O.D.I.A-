import math
print(math.sin(1))
print("=== THONNY FUNCTIONALITY TEST ===")

# 1. Basic output
print("1) Print test: OK")

# 2. Input test
name = input("2) Enter your name: ")
print(f"Hello, {name}!")

# 3. Math test
import math
print("3) Math test:")
print("   sqrt(16) =", math.sqrt(16))
print("   pi =", math.pi)

# 4. Loop and condition
print("4) Loop test:")
for i in range(3):
    print("   Count:", i)

# 5. File I/O test
print("5) File write/read test:")
filename = "thonny_test_output.txt"
with open(filename, "w") as f:
    f.write("This file was created by Thonny.\n")

with open(filename, "r") as f:
    content = f.read()

print("   File content:", content.strip())

# 6. Package test (optional)
print("6) Package test:")
try:
    import numpy as np
    arr = np.array([1, 2, 3])
    print("   NumPy installed:", arr * 2)
except ImportError:
    print("   NumPy NOT installed (this is OK if you didn't install it)")

# 7. Error handling test
print("7) Error handling test:")
try:
    x = 1 / 0
except ZeroDivisionError:
    print("   Caught ZeroDivisionError successfully")

print("\n=== ALL TESTS COMPLETED ===")
